# Project Retrospective

## Project Overview

This project involved planning, designing, developing, testing, and documenting a two-page professional website. The goal was not only to create a working website but also to practice project-management concepts throughout the process.

## What Went Well?

One thing that went well was keeping the project focused. The original scope already identified a personal professional website as the main goal, so the final project could build on that foundation rather than introducing an unrelated topic.

The website structure also worked well because the project has a clear separation between the homepage and About page. The homepage provides a quick introduction, while the second page gives more detail about professional interests and goals.

Using one external stylesheet helped keep the design consistent across both pages. The responsive layout also made it possible to organize the content for both larger and smaller screens.

Another positive part of the project was connecting the technical work with project-management concepts. Breaking the work into planning, content, development, documentation, testing, and deployment made the project easier to organize.

## What Went Wrong?

A challenge was making sure that the project did not become larger than the assignment required. It can be tempting to add additional pages, features, or interactive elements, but doing so could make the project harder to finish and test.

Another potential problem was balancing website design with documentation. The project requires several Markdown documents in addition to the actual website. Because of this, the documentation needed to be treated as part of the project rather than something to complete at the last minute.

Testing is also an area that requires attention. A website can look correct while still having broken links or layout problems on smaller screens. This means that checking only the desktop version would not be enough.

## What Would I Do Differently?

If I completed a similar project again, I would create the file structure and task checklist even earlier. Having the final repository structure established at the beginning would make it easier to keep track of completed and unfinished work.

I would also test the website after each major development step instead of waiting until the end. This would make it easier to identify the specific change that caused a problem.

Finally, I would spend more time planning the visual design before writing the CSS. A simple design plan for typography, spacing, navigation, and page sections would make the development process more predictable.

## Key Takeaway

The biggest lesson from this project is that a successful website requires more than writing code. Planning the scope, organizing tasks, identifying risks, testing the result, and reflecting on the process are all important parts of completing a digital project.

This project helped connect technical skills with project-management skills and provided a foundation for future web and computer-application projects.
