# Project Scope Statement

## Project Title

**Sophia Calderon Professional Website**

## Project Purpose

The purpose of this project is to create a simple, professional two-page website that represents my education, professional interests, career goals, and developing technical skills. The website focuses on Computer Applications, technology, digital evidence, and criminal justice.

The project also gives me an opportunity to practice project management concepts by defining the project's scope, planning tasks, identifying risks, and reflecting on the development process.

## Project Description

The final product is a responsive personal website consisting of a homepage and an About page. Both pages use one shared external CSS stylesheet so the site has a consistent visual design.

The homepage introduces my professional interests and career direction. The About page provides additional information about my goals and the technical and project-management skills I am developing.

The project is intended to be hosted through GitHub Pages and organized in a public GitHub repository with supporting documentation.

## Goals

1. Create a professional and easy-to-navigate two-page website.
2. Practice writing semantic HTML and using an external CSS stylesheet.
3. Apply responsive design principles so the website works on smaller screens.
4. Organize project files in a clear GitHub repository.
5. Apply project-management concepts including scope planning, risk analysis, scheduling, and retrospective reflection.
6. Create a portfolio-ready project that demonstrates both technical and planning skills.

## Deliverables

- `index.html`
- `about.html`
- `style.css`
- `README.md`
- `docs/scope.md`
- `docs/plan.md`
- `docs/retrospective.md`
- Public GitHub repository
- GitHub Pages website

## Target Audience

The primary audience is instructors, classmates, potential employers, and other people interested in learning about my professional direction and technical development.

## In Scope

- Two linked HTML pages
- Shared external CSS stylesheet
- Responsive layout
- Navigation
- Professional introduction
- Career interests and goals
- Hobbies and interests
- GitHub links
- Project documentation
- GitHub Pages deployment

## Out of Scope

- A large multi-page professional portfolio
- User accounts or login systems
- A database
- E-commerce functionality
- Advanced JavaScript applications
- Collecting visitor information
- A fully developed criminal-justice software application

## Success Criteria

The project will be considered complete when:

- Both HTML pages load correctly.
- The homepage links to the About page.
- Both pages use the same external stylesheet.
- The layout is readable on desktop and mobile screens.
- The GitHub repository contains all required files.
- The README links to the live site and documentation.
- The website is published through GitHub Pages.
- The final files are organized and ready for submission.

## Constraints

The project is intentionally limited to a small website so that the focus remains on applying course concepts rather than building a complex application. The site must use HTML and CSS and must fit within the assignment's GitHub repository requirements.
