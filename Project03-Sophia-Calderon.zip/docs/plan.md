# Project Plan

## Project Overview

The goal of this project is to create and publish a responsive two-page professional website while documenting the project-management process.

The project will be completed in phases: planning, content development, website development, testing, documentation, and deployment.

## Work Breakdown Structure

### 1. Project Planning
1.1 Review assignment requirements  
1.2 Review previous project scope  
1.3 Define final website purpose  
1.4 Identify required deliverables  

### 2. Content Development
2.1 Write homepage introduction  
2.2 Write professional-interest content  
2.3 Write About page content  
2.4 Select hobbies and interests  
2.5 Review content for clarity and consistency  

### 3. Website Development
3.1 Create `index.html`  
3.2 Create `about.html`  
3.3 Create shared `style.css`  
3.4 Add navigation links  
3.5 Add responsive design  
3.6 Test page structure and links  

### 4. Documentation
4.1 Revise project scope  
4.2 Create project plan  
4.3 Complete TAME risk analysis  
4.4 Create retrospective  
4.5 Update README  

### 5. Testing and Deployment
5.1 Test both pages in a browser  
5.2 Test navigation  
5.3 Test mobile layout  
5.4 Organize GitHub repository  
5.5 Publish with GitHub Pages  
5.6 Verify live website  
5.7 Prepare screenshots and ZIP submission  

## Simple Schedule

| Phase | Tasks | Planned Time |
|---|---|---|
| Planning | Requirements, scope, deliverables | Day 1 |
| Content | Write and revise website content | Day 2 |
| Development | HTML and CSS | Days 3–4 |
| Documentation | Scope, plan, README, retrospective | Day 5 |
| Testing | Browser, links, responsive layout | Day 6 |
| Deployment | GitHub Pages and final verification | Day 7 |
| Submission | Screenshots and ZIP file | Day 7 |

## TAME Risk Analysis

TAME stands for **Transfer, Accept, Mitigate, and Eliminate**. The framework is used to decide how to respond to project risks.

| Risk | Probability | Impact | TAME Response | Response Plan |
|---|---|---|---|---|
| Project takes longer than expected | Medium | High | Mitigate | Break the project into smaller tasks and work in stages. |
| HTML/CSS errors prevent pages from displaying correctly | Medium | High | Mitigate | Test each page after major changes and check the browser console/HTML structure. |
| Navigation links do not work | Low | Medium | Eliminate | Test every navigation link before submission. |
| Website is difficult to read on a phone | Medium | Medium | Mitigate | Use responsive CSS and test the pages at smaller screen widths. |
| GitHub Pages deployment has an issue | Low | High | Mitigate | Verify repository settings and test the published URL before submitting. |
| A small visual issue remains after testing | Medium | Low | Accept | Fix major usability problems first and accept minor cosmetic issues if they do not affect functionality. |
| Additional features expand the project beyond the assignment | Medium | Medium | Eliminate | Keep the project limited to two pages and the required documentation. |
| A task depends on another unfinished task | Medium | Medium | Transfer | Move dependent work into the next available project stage rather than blocking unrelated work. |

## Quality Checklist

Before submission, I will verify:

- [ ] `index.html` works.
- [ ] `about.html` works.
- [ ] Both pages use `style.css`.
- [ ] Navigation works.
- [ ] GitHub link works.
- [ ] Website is readable on a smaller screen.
- [ ] README contains project information and links.
- [ ] `docs/` contains all three required documents.
- [ ] GitHub Pages site is live.
- [ ] Final screenshot includes both pages.
- [ ] All project files are included in the ZIP.
