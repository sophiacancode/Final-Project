# Sophia Calderon — Professional Website

A two-page professional website created for COMP 3301 Project 03. The project combines web development with project planning and documentation.

## Project Purpose

This website presents my professional interests in Computer Applications, technology, criminal justice, and digital evidence. It is designed to demonstrate basic HTML/CSS skills while also serving as a small professional portfolio project.

## Live Website

[View the live website](https://sophiacancode.github.io/)

## GitHub Repository

[View the GitHub repository](https://github.com/sophiacancode)

## Pages

- **Home (`index.html`)** — Introduction, professional interests, career goal, and hobbies.
- **About (`about.html`)** — More information about my direction, goals, and developing skills.

## Documentation

Project planning documents are located in the `docs/` folder:

- [Project Scope](docs/scope.md)
- [Project Plan & TAME Risk Analysis](docs/plan.md)
- [Project Retrospective](docs/retrospective.md)

## Technologies

- HTML5
- CSS3
- GitHub Pages

## Project Structure

```text
project-03/
├── index.html
├── about.html
├── style.css
├── README.md
└── docs/
    ├── scope.md
    ├── plan.md
    └── retrospective.md
```

## Author

Sophia Calderon  
GitHub: https://github.com/sophiacancode
